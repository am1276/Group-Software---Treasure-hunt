
var get_and_submitList=function(){

        var user = document.getElementById("user").value; 
        var li = "<li>" + user + "</li>";
        var list_usernames=document.getElementById("list").value;
      list_usernames.insertAdjacentHTML('beforeend', li);
       
        //ajax code for submitting the list of usernames

}

var validation_teamsNumber=function(){

var teams_number=document.getElementById("number_teams").value;


if(teams_number==""){

  alert("Please introduce a number");
  
  return false;

}else{


  return true;
}



var get_OTP=function(){

   const OTP=Math.floor(Math.random()*5000000 ); 


    return OTP;

}
    
    function get_name()
    { 
      
        var name = document.getElementById("user").value;
       document.getElementById("user").innerHTML;
      }
        


        function validation_username(){
      
          var name = document.getElementById("user").value;

if(name==""){

alert("Please introduce a valid username");

return;

      }else{

    submit_username();

          function submit_username() {
            name.submit();
          }
        }
    } 


//We get the teams and one-time-passwords for each player and submit teams-arrays for each user in the database.
    var get_and_submitTeams=function(){
 

        console.log("Started team division");

      // var number_teams=document.getElementById("number_teams").value//BUG

        var max_players_team=4;

       var number_teams=1;

        var i;
        var j;
        
        let Teams=new Array(number_teams);

        for ( i = 0; i < number_teams; i++) {
     

            
           for (j = 0; j < max_players_team; j++) {//max_players_team tiene que ser la length de la lista de la base de datos

            get_input(name);

                Teams[i] = new Array(max_players_team);


if(OTP%2==0){

    Teams[i][j]=name;
    console.log(name);
    console.log(i, j);
    
   document.write("<br>You are part of team " + i);
   break;

   }
   
   else {
    Teams[i][j]=name;
    console.log(name);
    console.log(i, j);
    ++i;
  
    Teams[i][j]=name;
    
    document.write("<br>You are part of team " + i);
 

    break;


   }
            }
break;

}
document.write("<br>All players in");
console.log("All players in");
//ajax code here for submitting the teams for each username and the number for teams in gamekeeper interface
        }

        //poner un else aqui para saber que el maximo numero de equipos se ha alcanazado

